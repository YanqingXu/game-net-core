from __future__ import annotations

import hashlib
import json
import statistics
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[3]
BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "tools"))
from hot_path_cost_common import child_parameters, validate_child
from validate_hot_path_cost import validate_manifest


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def json_document(path: Path):
    return json.loads(path.read_bytes().decode("utf-8-sig"))


def field(document, name: str):
    for key in name.split("."):
        document = document[key]
    return document


def summarize_metric(definition, values):
    assert len(values) == 10
    median = statistics.median(values)
    if all(isinstance(value, bool) for value in values):
        assert len(set(values)) == 1, "exact boolean guard changed across samples"
        median = values[0]
    return {
        "name": definition["name"],
        "direction": definition["direction"],
        "raw_source": definition["source"],
        "sample_count": len(values),
        "median": median,
        "min": min(values),
        "max": max(values),
    }


inventory_path = ROOT / "benchmarks/hot_path_cost_inventory.json"
inventory = json_document(inventory_path)
inventory_hash = sha256(inventory_path)
expected_sha = "41ba8f4ebeda784ff2952b87e53b48310d4f053f"
definitions = {entry["key"]: entry for entry in inventory["scenarios"]}
summary = {
    "schema": "gamenet.local_hot_path_summary.v1",
    "status": "validated-development-baseline",
    "evidence_class": "development",
    "promotion_eligible": False,
    "exact_commit_sha": expected_sha,
    "inventory_sha256": inventory_hash,
    "statistical_scope": "Ten recorded samples per scenario; warmups excluded from statistics.",
    "comparison_boundary": "These are separate OS/environment baselines, not a paired candidate comparison or a backend performance ranking.",
    "formal_hp0_status": "DEFER",
    "formal_limitations": [
        "No configured cost observer; each ledger has 380 missing required sample-cost entries.",
        "Linux evidence executes under WSL Ubuntu 24.04, not native Linux.",
        "CPU affinity and frequency policy are not fixed reviewed lab controls.",
        "No 5%/3% promotion or default-path integration decision is made.",
    ],
    "platforms": {},
}

for platform in ("windows", "linux"):
    directory = BASE / platform
    ledger_path = directory / "hot-path-cost.json"
    ledger = validate_manifest(ledger_path, inventory_path, False)
    assert ledger["identity"]["commit_sha"] == expected_sha
    assert ledger["identity"]["working_tree"] == "clean"
    assert ledger["inventory"]["sha256"] == inventory_hash
    assert ledger["promotion_eligible"] is False
    assert ledger["evidence_class"] == "development"
    assert len(ledger["scenarios"]) == 6
    assert ledger["sampling"] == {
        "warmups_per_scenario": 1,
        "recorded_samples_per_scenario": 10,
        "order": "scenario-round-robin",
    }
    platform_summary = {
        "ledger_path": ledger_path.relative_to(ROOT).as_posix(),
        "ledger_sha256": sha256(ledger_path),
        "inventory_sha256": inventory_hash,
        "identity": ledger["identity"],
        "environment": ledger["environment"],
        "executables": ledger["executables"],
        "observer": ledger["observer"],
        "sampling": ledger["sampling"],
        "validation": {
            "validator": "tools/validate_hot_path_cost.py",
            "validator_sha256": sha256(ROOT / "tools/validate_hot_path_cost.py"),
            "development_passed": True,
            "recorded_raw_hashes_and_parameters_verified": True,
            "raw_stdout_and_command_sidecars_independently_verified": True,
            "warmup_semantics_and_parameters_independently_verified": True,
        },
        "promotion_eligible": False,
        "scenarios": [],
    }
    artifact_hashes = []
    missing_entries = []
    for scenario in ledger["scenarios"]:
        key = scenario["key"]
        definition = definitions[key]
        assert scenario["arguments"] == definition["arguments"]
        assert len(scenario["samples"]) == 10
        primary_values = []
        guard_values = {guard["name"]: [] for guard in definition["guardrails"]}
        missing_by_cost = {cost: 0 for cost in definition["required_costs"]}
        for ordinal in range(11):
            role = "warmup" if ordinal == 0 else f"sample-{ordinal:02d}"
            stem = directory / "raw" / key / f"{role}.observation"
            stdout_path = stem.with_suffix(".observation.stdout.bin")
            stderr_path = stem.with_suffix(".observation.stderr.bin")
            command_path = stem.with_suffix(".observation.command.json")
            command = json_document(command_path)["argv"]
            assert command == [ledger["executables"][scenario["executable"]]["path"], *definition["arguments"]]
            raw = json_document(stdout_path)
            validated = validate_child(raw, definition, ledger["identity"]["platform"], ledger["identity"]["backend"], "Release", f"{platform}/{key}/{role}")
            assert child_parameters(validated, definition) == scenario["child_parameters"]
            for artifact in (stdout_path, stderr_path, command_path):
                artifact_hashes.append({"path": artifact.relative_to(directory).as_posix(), "sha256": sha256(artifact)})
            if ordinal == 0:
                continue
            sample = scenario["samples"][ordinal - 1]
            canonical_raw = json_document(directory / sample["raw_path"])
            assert canonical_raw == validated
            primary = field(validated, definition["primary"]["source"])
            assert primary == sample["primary"]["value"]
            primary_values.append(primary)
            for index, guard in enumerate(definition["guardrails"]):
                value = field(validated, guard["source"])
                assert value == sample["guardrails"][index]["value"]
                guard_values[guard["name"]].append(value)
            for cost in definition["required_costs"]:
                if sample["costs"][cost] is None:
                    missing_by_cost[cost] += 1
                    missing_entries.append(f"{key}#{ordinal}:{cost}")
        platform_summary["scenarios"].append({
            "key": key,
            "baseline": scenario["baseline"],
            "arguments": scenario["arguments"],
            "child_parameters": scenario["child_parameters"],
            "primary": summarize_metric(definition["primary"], primary_values),
            "guardrails": [summarize_metric(guard, guard_values[guard["name"]]) for guard in definition["guardrails"]],
            "missing_required_cost_entries": sum(missing_by_cost.values()),
            "missing_required_cost_entries_by_name": {name: count for name, count in missing_by_cost.items() if count},
        })
    assert missing_entries == ledger["missing_required_costs"]
    assert len(missing_entries) == 380
    raw_stdout_paths = list((directory / "raw").glob("*/*.observation.stdout.bin"))
    sample_json_paths = list((directory / "raw").glob("*/sample-[0-9][0-9].json"))
    assert len(raw_stdout_paths) == 66
    assert len(sample_json_paths) == 60
    assert len(artifact_hashes) == 198
    platform_summary["unknown_required_cost_count"] = len(missing_entries)
    platform_summary["raw_counts"] = {
        "child_executions_with_original_stdout_stderr_and_command": len(raw_stdout_paths),
        "warmups": 6,
        "recorded_samples": len(sample_json_paths),
        "execution_sidecar_files": len(artifact_hashes),
    }
    encoded_hashes = json.dumps(sorted(artifact_hashes, key=lambda item: item["path"]), sort_keys=True, separators=(",", ":")).encode()
    platform_summary["raw_sidecar_manifest_sha256"] = hashlib.sha256(encoded_hashes).hexdigest()
    platform_summary["raw_sidecar_manifest_hash_scheme"] = "SHA256 of compact sorted-key JSON array of {path,sha256}, sorted by platform-relative POSIX path, UTF-8"
    capacity = next(item for item in platform_summary["scenarios"] if item["key"] == "connection-capacity.current")
    assert capacity["arguments"][capacity["arguments"].index("--connections") + 1] == "10000"
    summary["platforms"][platform] = platform_summary

summary["total_original_child_executions"] = 132
summary["total_recorded_samples"] = 120
summary["total_warmups"] = 12
output = BASE / "combined-summary.json"
output.write_text(json.dumps(summary, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
for platform, record in summary["platforms"].items():
    print(platform, "ledger_sha256", record["ledger_sha256"], "missing", record["unknown_required_cost_count"])
    for scenario in record["scenarios"]:
        primary = scenario["primary"]
        print(scenario["key"], primary["name"], primary["median"], primary["min"], primary["max"])
print("summary_sha256", sha256(output))
