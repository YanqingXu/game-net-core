import datetime, json, subprocess, sys
from pathlib import Path
repo = Path(__file__).resolve().parents[3]
root = Path(__file__).resolve().parent
command = [
    sys.executable, str(repo / "tools/run_hot_path_cost.py"),
    "--inventory", str(repo / "benchmarks/hot_path_cost_inventory.json"),
    "--source-root", str(repo),
    "--core-executable", str(repo / "out/build/local-hp0-windows/benchmarks/Release/gamenet_core_benchmark.exe"),
    "--phase4-executable", str(repo / "out/build/local-hp0-windows/benchmarks/Release/gamenet_phase4_benchmark.exe"),
    "--capacity-executable", str(repo / "out/build/local-hp0-windows/benchmarks/Release/gamenet_capacity_profile.exe"),
    "--queued-executable", str(repo / "out/build/local-hp0-windows/benchmarks/Release/gamenet_multi_io_queued_benchmark.exe"),
    "--output-root", str(root / "windows"),
    "--platform", "windows", "--backend", "iocp", "--build-type", "Release",
    "--commit-sha", "41ba8f4ebeda784ff2952b87e53b48310d4f053f",
    "--working-tree", "clean", "--evidence-class", "development", "--native-runner",
    "--runner-id", "local-windows-i5-14600k",
    "--cpu-model", "Intel(R) Core(TM) i5-14600K",
    "--cpu-affinity", "inherited mask 0xfffff; logical CPUs 0-19; no pinning",
    "--frequency-policy", "Balanced GUID 381b4222-f694-41f0-9685-ff5bb260df2e; unmanaged frequency",
    "--compiler", "MSVC 19.51.36256.0 (Visual Studio 18 2026), Release",
    "--command-context", "local native Windows original six HP0 scenarios after WSL Ubuntu24 sampling; no lab observer",
    "--warmups", "1", "--samples", "10", "--process-timeout-seconds", "180",
]
command_record = {"argv": command, "cwd": str(repo)}
if "--prepare-only" in sys.argv:
    (root / "windows.command.json").write_text(json.dumps(command_record, indent=2) + "\n", encoding="utf-8")
    print("prepared original six-scenario Windows 1+10 command; no benchmark launched")
    raise SystemExit(0)
command_record["started_utc"] = datetime.datetime.now(datetime.timezone.utc).isoformat()
(root / "windows.command.json").write_text(json.dumps(command_record, indent=2) + "\n", encoding="utf-8")
print("starting Windows baseline", command_record["started_utc"], flush=True)
with (root / "windows.runner.stdout.bin").open("wb") as stdout, (root / "windows.runner.stderr.bin").open("wb") as stderr:
    completed = subprocess.run(command, cwd=repo, stdout=stdout, stderr=stderr)
command_record["finished_utc"] = datetime.datetime.now(datetime.timezone.utc).isoformat()
command_record["returncode"] = completed.returncode
(root / "windows.command.json").write_text(json.dumps(command_record, indent=2) + "\n", encoding="utf-8")
print("Windows baseline exit", completed.returncode, command_record["finished_utc"], flush=True)
print((root / "windows.runner.stdout.bin").read_bytes().decode("utf-8", errors="replace"), end="")
print((root / "windows.runner.stderr.bin").read_bytes().decode("utf-8", errors="replace"), end="", file=sys.stderr)
raise SystemExit(completed.returncode)
